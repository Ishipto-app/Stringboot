package product.example.apiproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
