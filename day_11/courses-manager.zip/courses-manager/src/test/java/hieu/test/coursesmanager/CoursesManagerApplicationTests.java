package hieu.test.coursesmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoursesManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
