package hieu.test.coursesmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoursesManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoursesManagerApplication.class, args);
	}

}
