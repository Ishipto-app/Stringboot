package bean.example.beandemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeanDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeanDemoApplication.class, args);
	}

}
